LYN4X SKYBOX HUB - Upload all 120 PNG files and LYN4X_Skybox_Hub.lua to the ROOT of lyn4x-js/New- (main). Do not upload README unless desired.
Run:
loadstring(game:HttpGet("https://raw.githubusercontent.com/lyn4x-js/New-/main/LYN4X_Skybox_Hub.lua"))()
