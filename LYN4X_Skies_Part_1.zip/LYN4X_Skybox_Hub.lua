-- LYN4X Skybox Hub | 20 Voidstrap packs | Delta/iPad experimental
-- Upload this Lua and LYN4X_01_bk.png ... LYN4X_20_up.png to repository root.
-- Client-side cosmetic only. Requires writefile + getcustomasset/getsynasset.

local Lighting = game:GetService("Lighting")
local Players = game:GetService("Players")
local BASE = "https://raw.githubusercontent.com/lyn4x-js/New-/main/"
local PACKS = {
    "Beautfil",
    "Blue",
    "Chill gray",
    "ChromaKey",
    "Default",
    "Light Blue",
    "Light pink",
    "Minesky",
    "NeonSky",
    "NeonSky2",
    "Pandora",
    "PlanetCyan",
    "PurpleVoid",
    "RemRam",
    "Yumeko",
    "grimnight",
    "homer uchiha skybox",
    "jungle csgo",
    "sky purple",
    "sky2006"
}
local FACES = {SkyboxBk="bk",SkyboxDn="dn",SkyboxFt="ft",SkyboxLf="lf",SkyboxRt="rt",SkyboxUp="up"}
local assetFn = getcustomasset or getsynasset
local env = getgenv and getgenv() or _G
if env.__LYN4XSkyHub and env.__LYN4XSkyHub.stop then
    pcall(env.__LYN4XSkyHub.stop)
end
local state = {alive=true, auto=true, selected=12, current=nil, assets={}, connections={}, applying=false, busy=false}
env.__LYN4XSkyHub = state
local saved = {}
for _,v in ipairs(Lighting:GetChildren()) do
    if v:IsA("Sky") then table.insert(saved,v:Clone()) end
end
local function conn(signal,fn)
    local c=signal:Connect(fn)
    table.insert(state.connections,c)
end
local function stop()
    state.alive=false
    for _,c in ipairs(state.connections) do pcall(function() c:Disconnect() end) end
    state.connections={}
end
state.stop=stop

local gui=Instance.new("ScreenGui")
gui.Name="LYN4X_Skybox_Hub"
gui.ResetOnSpawn=false
gui.IgnoreGuiInset=true
pcall(function() gui.Parent=game:GetService("CoreGui") end)
if not gui.Parent then gui.Parent=Players.LocalPlayer:WaitForChild("PlayerGui") end
state.gui=gui
local function make(class,parent,props)
    local obj=Instance.new(class)
    for k,v in pairs(props or {}) do obj[k]=v end
    obj.Parent=parent
    return obj
end
local panel=make("Frame",gui,{Size=UDim2.fromOffset(300,410),Position=UDim2.new(0,18,0.5,-205),BackgroundColor3=Color3.fromRGB(20,20,25),BorderSizePixel=0,Active=true,Draggable=true})
make("UICorner",panel,{CornerRadius=UDim.new(0,12)})
make("UIStroke",panel,{Color=Color3.fromRGB(0,180,220),Thickness=1.5})
make("TextLabel",panel,{Size=UDim2.new(1,-45,0,42),Position=UDim2.fromOffset(12,0),BackgroundTransparency=1,Text="LYN4X  •  SKYBOX HUB",Font=Enum.Font.GothamBold,TextSize=17,TextColor3=Color3.fromRGB(130,225,255),TextXAlignment=Enum.TextXAlignment.Left})
local close=make("TextButton",panel,{Size=UDim2.fromOffset(32,32),Position=UDim2.new(1,-38,0,5),Text="×",TextSize=24,TextColor3=Color3.new(1,1,1),BackgroundColor3=Color3.fromRGB(55,55,60)})
make("UICorner",close,{CornerRadius=UDim.new(0,7)})
local scroll=make("ScrollingFrame",panel,{Size=UDim2.new(1,-20,0,255),Position=UDim2.fromOffset(10,45),BackgroundColor3=Color3.fromRGB(30,30,35),BorderSizePixel=0,ScrollBarThickness=5,CanvasSize=UDim2.fromOffset(0,20*35)})
make("UICorner",scroll,{CornerRadius=UDim.new(0,8)})
make("UIListLayout",scroll,{Padding=UDim.new(0,2),SortOrder=Enum.SortOrder.LayoutOrder})
local status=make("TextLabel",panel,{Size=UDim2.new(1,-20,0,35),Position=UDim2.fromOffset(10,303),BackgroundTransparency=1,Text="Selected: PlanetCyan (#12)",TextColor3=Color3.fromRGB(220,220,220),TextSize=12,TextWrapped=true,Font=Enum.Font.Gotham,TextXAlignment=Enum.TextXAlignment.Left})
local function button(label,x,w)
    local b=make("TextButton",panel,{Size=UDim2.new(w,-6,0,37),Position=UDim2.new(x,4,0,341),BackgroundColor3=Color3.fromRGB(38,94,110),TextColor3=Color3.new(1,1,1),Text=label,Font=Enum.Font.GothamBold,TextSize=12})
    make("UICorner",b,{CornerRadius=UDim.new(0,8)})
    return b
end
local applyBtn=button("APPLY",0,0.32)
local autoBtn=button("AUTO: ON",0.32,0.36)
local resetBtn=button("RESET",0.68,0.32)
make("TextLabel",panel,{Size=UDim2.new(1,-20,0,22),Position=UDim2.fromOffset(10,382),BackgroundTransparency=1,Text="Drag header • scroll to select • client-side",TextSize=10,TextColor3=Color3.fromRGB(150,150,150)})
local entries={}
local function updateSelection()
    for i,b in ipairs(entries) do
        b.BackgroundColor3=(i==state.selected) and Color3.fromRGB(35,105,125) or Color3.fromRGB(43,43,50)
    end
    status.Text="Selected: "..PACKS[state.selected].." (#"..state.selected..")"
end
for i,name in ipairs(PACKS) do
    local b=make("TextButton",scroll,{Size=UDim2.new(1,-8,0,33),BackgroundColor3=Color3.fromRGB(43,43,50),BorderSizePixel=0,Text=string.format("%02d  %s",i,name),TextColor3=Color3.new(1,1,1),Font=Enum.Font.Gotham,TextSize=13,TextXAlignment=Enum.TextXAlignment.Left,LayoutOrder=i})
    make("UICorner",b,{CornerRadius=UDim.new(0,5)})
    entries[i]=b
    conn(b.MouseButton1Click,function() state.selected=i;updateSelection() end)
end
updateSelection()

local function loadPack(i)
    if state.assets[i] then return state.assets[i] end
    assert(type(writefile)=="function" and type(assetFn)=="function","Delta needs writefile and getcustomasset/getsynasset")
    local result={}
    for prop,suffix in pairs(FACES) do
        local filename=string.format("LYN4X_%02d_%s.png",i,suffix)
        local localName="LYN4X_CACHE_"..filename
        local exists=false
        if type(isfile)=="function" then
            local ok,v=pcall(isfile,localName)
            exists=ok and v
        end
        if not exists then
            local data=game:HttpGet(BASE..filename)
            assert(type(data)=="string" and #data>100 and (data:sub(1,4)=="\137PNG"),"Missing or invalid image: "..filename)
            writefile(localName,data)
        end
        result[prop]=assetFn(localName)
    end
    state.assets[i]=result
    return result
end
local function ensureSky()
    if not state.alive or not state.current or state.applying then return end
    state.applying=true
    local ok,err=pcall(function()
        local sky=Lighting:FindFirstChild("LYN4X_ACTIVE_SKY")
        if not sky or not sky:IsA("Sky") then
            if sky then sky:Destroy() end
            sky=Instance.new("Sky")
            sky.Name="LYN4X_ACTIVE_SKY"
            sky.Parent=Lighting
        end
        for prop,asset in pairs(state.assets[state.current] or {}) do
            if sky[prop]~=asset then sky[prop]=asset end
        end
        for _,other in ipairs(Lighting:GetChildren()) do
            if other:IsA("Sky") and other~=sky then other:Destroy() end
        end
    end)
    state.applying=false
    if not ok then status.Text="Sky error: "..tostring(err) end
end
local function applySelected()
    if state.busy then return end
    state.busy=true
    applyBtn.Text="LOADING..."
    status.Text="Downloading "..PACKS[state.selected].."..."
    local chosen=state.selected
    task.spawn(function()
        local ok,err=pcall(function()
            loadPack(chosen)
            if not state.alive then return end
            state.current=chosen
            ensureSky()
        end)
        if state.alive then
            status.Text=ok and ("Applied: "..PACKS[chosen].." (#"..chosen..")") or ("ERROR: "..tostring(err))
            applyBtn.Text="APPLY"
            state.busy=false
        end
    end)
end
conn(applyBtn.MouseButton1Click,applySelected)
conn(autoBtn.MouseButton1Click,function()
    state.auto=not state.auto
    autoBtn.Text=state.auto and "AUTO: ON" or "AUTO: OFF"
    if state.auto then ensureSky() end
end)
conn(resetBtn.MouseButton1Click,function()
    state.current=nil
    for _,v in ipairs(Lighting:GetChildren()) do
        if v:IsA("Sky") then v:Destroy() end
    end
    for _,original in ipairs(saved) do original:Clone().Parent=Lighting end
    status.Text="Original sky restored • select Apply to resume"
end)
conn(close.MouseButton1Click,function()
    stop()
    gui:Destroy()
end)
conn(Lighting.ChildAdded,function(v)
    if state.auto and state.current and v:IsA("Sky") then task.defer(ensureSky) end
end)
conn(Lighting.ChildRemoved,function(v)
    if state.auto and state.current and v:IsA("Sky") then task.defer(ensureSky) end
end)
task.spawn(function()
    while state.alive do
        task.wait(2)
        if state.auto and state.current then ensureSky() end
    end
end)
-- Apply #12 initially to match the working PlanetCyan test.
applySelected()
print("[LYN4X] Hub loaded: 20 skies; Auto Sky enabled")
